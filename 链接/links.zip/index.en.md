---
title: Links
links:
  - title: 哔哩哔哩
    description: Chinese long video website
    website: https://space.bilibili.com/481860240
    image: bilibili.png
  - title: QQ频道
    description: voice channel
    website: https://pd.qq.com/s/429a583q3
    image: https://groupprohead.gtimg.cn/646946414021687038/100?t=0
  - title: 网易云音乐
    description: Delivering the Power of Good with Music
    website: https://music.163.com/#/user?id=3584381343
    image: wyy.png
  - title: KOOK
    description: KOOK is a voice and grouping tool for gamers.
    website: https://kook.vip/r8uju2
    image: https://saas.bk-cdn.com/1716199994562-KOOKLOGO.png
  - title: Oopz
    description: Let the game connect us
    website: https://oopz.cn/i/rupVJ9
    image: https://is1-ssl.mzstatic.com/image/thumb/Purple221/v4/3c/2b/53/3c2b5361-9001-bbc1-0b7f-c3e89b187288/AppIcon-0-0-1x_U007emarketing-0-7-0-0-85-220.png/230x0w.webp
  - title: X
    description: X. What happened? / X
    website: https://x.com/baiqiandada
    image: brand-x.svg
  - title: YouTube
    description: The world's largest video website
    website: https://www.youtube.com/@baiqiandada
    image: youtube.png
  - title: pixiv
    description: Illustration Exchange
    website: https://www.pixiv.net/users/113844869
    image: pixiv.jpeg
  - title: Reddit
    description: The Heart of the Internet
    website: https://www.reddit.com/user/baiqiandada/
    image: https://redditinc.com/hs-fs/hubfs/Reddit%20Inc/Content/Brand%20Page/Reddit_Logo.png?width=400&height=400&name=Reddit_Logo.png
  - title: Discord
    description: communication tool
    website: https://discord.gg/Nua3zrXfCb
    image: discord.svg
  - title: Bulesky
    description: is a decentralized and distributed micro-blogging social network
    website: https://bsky.app/profile/baiqiandada.bsky.social
    image: https://upload.wikimedia.org/wikipedia/commons/7/7a/Bluesky_Logo.svg
  - title: Twitch
    description: live broadcasting platform
    website: https://www.twitch.tv/baiqiandada
    image: twitch.svg
  - title: Instagram
    description: Social Networking Platform
    website: https://www.instagram.com/whiteshallow/
    image: https://upload.wikimedia.org/wikipedia/commons/e/e7/Instagram_logo_2016.svg
  - title: Spotify
    description: Music Platform
    website: https://open.spotify.com/user/31sktjt533c5qpvfqrqqlk5p3tmq
    image: https://upload.wikimedia.org/wikipedia/commons/1/19/Spotify_logo_without_text.svg
  - title: Tiktok
    description: TikTok
    website: https://www.tiktok.com/@baiqiandada6
    image: tiktok.png
  - title: FaceBook
    description: Social Networking Services website
    website: https://www.facebook.com/profile.php?id=61572776046757
    image: https://www.bing.com/th?id=OSK.FRO_m17RzvcZTJ6fGHnoTJtTZF47VAdOCVFcp6e6ibA&w=120&h=120&qlt=120&c=6&rs=1&cdv=1&pid=RS
  - title: Steam
    description: gaming platform
    website: https://steamcommunity.com/id/666888886/
    image: https://upload.wikimedia.org/wikipedia/commons/8/83/Steam_icon_logo.svg
  - title: Epic
    description: gaming platform
    website: https://store.epicgames.com/zh-CN/u/5069065a5a08448e9480f33775064152
    image: https://upload.wikimedia.org/wikipedia/commons/3/31/Epic_Games_logo.svg
  - title: Xbox
    description: Console Game Platforms
    website: https://www.xbox.com/zh-HK/play/user/Baiqiandada6
    image: https://upload.wikimedia.org/wikipedia/commons/d/d7/Xbox_logo_%282019%29.svg
menu:
    main: 
        weight: -50
        params:
            icon: link
---