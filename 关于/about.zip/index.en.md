---
title: About
menu:
    main: 
        weight: -90
        params:
            icon: user
---

## 2025

### May
- **18**  
  Successfully built my first personal website 🥰  

### March  
- **A whole month**  
  Annual listening time on NetEuse Cloud Music surpassed 197 hours 🎧  
  *"Is it true love for music, or is loneliness at play?"* 🧐  

### February
- **10**  
  Designed and drew a custom Minecraft skin 🎨  

---

## 2024

### August
- **22**  
  Japan first discharged nuclear-contaminated water into the Pacific Ocean 😡  

- **14**  
  Purchased *Black Myth: Wukong* in full 🎮  
  *"Witnessing a milestone for domestic 3A games, eagerly awaiting the next Chinese 3A masterpiece"* 🥰  

### June
- **Unknown Specific time**  
  Deeply immersed in the world of single-player console games 🕹️😍  
  *"In open worlds, I am both a traveler and a creator"*  

### May
- **19**  
  Finally bought a legitimate Minecraft license a decade late 🧾😀  

### January
- **Unknown Specific time**  
  Completed my first 3A game *Dying Light* for the first time 🧟♂️😁  

---

## 2023

### August
- **Unknown Specific time**  
  Saw the "outside" world for the first time ✈️🧐  
  *(via VPN)* 🤓  

### July
- **10**  
  Acquired my first Windows computer 💻🥳  

### May
- **Unknown Specific time**  
  Fell deeply into the rap music universe 🎤😘  
  *"From Old School to Trap, finding self-expression through the art of rhyme."*  

---

## 2018

- **Unknown date**  
  Got my first smartphone 📱😋  

---

## 2009

### March
- **23**  
  Entered the theater of life 🌍😶‍🌫️  
  *"Is this a preset script, or a montage of free will?"*  